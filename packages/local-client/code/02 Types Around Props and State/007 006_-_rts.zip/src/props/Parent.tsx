import { Child } from './Child';

const Parent = () => {
  return <Child color="red" />;
};

export default Parent;
