import { Child } from './Child';

const Parent = () => {
  return <Child />;
};

export default Parent;
