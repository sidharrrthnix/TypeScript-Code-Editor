declare module 'monaco-jsx-highlighter';
declare module 'react-split';
