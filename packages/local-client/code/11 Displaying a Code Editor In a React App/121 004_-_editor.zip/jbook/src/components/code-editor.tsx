import MonacoEditor from '@monaco-editor/react';

const CodeEditor = () => {
  return <MonacoEditor height="500px" />;
};

export default CodeEditor;
