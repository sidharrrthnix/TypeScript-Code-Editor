import ReactDOM from 'react-dom';

const App = () => {
  return <h1>hi</h1>;
};

ReactDOM.render(<App />, document.querySelector('#root'));
