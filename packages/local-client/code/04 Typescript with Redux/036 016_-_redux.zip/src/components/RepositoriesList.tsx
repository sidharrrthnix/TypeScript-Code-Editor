const RepositoriesList: React.FC = () => {
  return (
    <div>
      <form>
        <input />
        <button>Search</button>
      </form>
    </div>
  );
};

export default RepositoriesList;
