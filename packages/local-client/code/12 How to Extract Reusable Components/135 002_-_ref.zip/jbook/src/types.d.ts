declare module 'monaco-jsx-highlighter';
