module.exports = () => {
  console.log('Server is listening');
};
