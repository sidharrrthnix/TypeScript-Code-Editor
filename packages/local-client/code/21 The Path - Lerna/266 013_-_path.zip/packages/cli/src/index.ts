import serve from 'local-api';

serve();
