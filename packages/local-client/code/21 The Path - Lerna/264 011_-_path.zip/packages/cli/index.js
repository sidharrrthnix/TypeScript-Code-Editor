const serve = require('local-api');

serve();
