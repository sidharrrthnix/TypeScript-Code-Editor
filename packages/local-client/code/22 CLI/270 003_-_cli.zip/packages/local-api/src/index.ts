export default () => {
  console.log('Server is listening');
};
